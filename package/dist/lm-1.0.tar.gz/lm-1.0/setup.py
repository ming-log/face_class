# !/usr/bin/python3
# -*- coding:utf-8 -*- 
# author: Ming Luo
# time: 2020/8/28 11:52

from distutils.core import setup

setup(name="lm",  # 包名
      version="1.0",  # 版本
      description="lm's send and receive",   #描述信息
      long_description="complete information", # 完整描述信息
      author="ming luo", # 作者
      author_email="736704198@qq.com",  # 作者邮箱
      url="www.lm.com",  # 主页
      py_modules=["lm.send_message",
                   "lm.receive_message"])   # 要发布的模块


