# !/usr/bin/python3
# -*- coding:utf-8 -*- 
# author: Ming Luo
# time: 2020/8/28 11:33


def receive():
    print("receive 函数")




